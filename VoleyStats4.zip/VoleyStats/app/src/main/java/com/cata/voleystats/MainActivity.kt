package com.cata.voleystats

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.cata.voleystats.ui.theme.VoleyStatsTheme
import androidx.compose.runtime.mutableStateOf
import com.cata.voleystats.ui.PantallaInicial
import androidx.compose.material3.Text
import com.cata.voleystats.ui.PantallaSeleccionEquipos





class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VoleyStatsTheme {
                val navController = rememberNavController()

                // Estados compartidos
                val columnasGanadas = remember { mutableStateListOf("Saque", "Remate", "Espacio Vacío") }
                val columnasPerdidas = remember { mutableStateListOf("Choque", "Flecha", "Doble Golpe") }
                val equipoLocal = remember { mutableStateOf("") }
                val equipoVisitante = remember { mutableStateOf("") }

                NavHost(navController = navController, startDestination = "pantallaInicial") {

                    composable("pantallaInicial") {
                        PantallaInicial(navController)
                    }

                    composable("seleccionEquipos") {
                        PantallaSeleccionEquipos(
                            equipoLocal = equipoLocal,
                            equipoVisitante = equipoVisitante,
                            onElegirFavorito = {
                                // Lógica futura para favoritos
                            },
                            navController = navController
                        )
                    }


                    composable("personalizacion") {
                        PantallaPersonalizacion(
                            columnasGanadas,
                            columnasPerdidas,
                            equipoLocal,
                            equipoVisitante,
                            onFinalizar = { navController.navigate("estadisticas") }
                        )
                    }

                    composable("estadisticas") {
                        PantallaEstadisticas(
                            columnasGanadas,
                            columnasPerdidas,
                            equipoLocal.value,
                            equipoVisitante.value,
                            onVolver = { navController.popBackStack() },
                            onPartidoFinalizado = {
                                navController.navigate("historial")
                            }
                        )
                    }

                    composable("historial") {
                        PantallaHistorial(
                            onVolver = { navController.navigate("personalizacion") }
                        )
                    }

                    composable("gestionEquipos") {
                        Text("Pantalla Gestión de Equipos (próximamente)")
                    }
                }


            }
        }

    }
}
