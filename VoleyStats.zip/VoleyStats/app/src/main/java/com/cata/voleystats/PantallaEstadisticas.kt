package com.cata.voleystats

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import com.cata.voleystats.data.DatabaseProvider
import com.cata.voleystats.data.PartidoEntity
import com.cata.voleystats.data.JugadorEntity

data class Jugador(
    var nombre: String,
    var puntosGanados: MutableMap<String, Int>,
    var puntosPerdidos: MutableMap<String, Int>
)

@Composable
fun PantallaEstadisticas(
    columnasGanadas: List<String>,
    columnasPerdidas: List<String>,
    equipoLocal: String,
    equipoVisitante: String,
    onVolver: () -> Unit,
    onPartidoFinalizado: () -> Unit

) {
    val jugadores = remember {
        mutableStateListOf<Jugador>().apply {
            repeat(12) {
                add(
                    Jugador(
                        nombre = "Jugador ${it + 1}",
                        puntosGanados = mutableStateMapOf<String, Int>().apply {
                            columnasGanadas.forEach { this[it] = 0 }
                        },
                        puntosPerdidos = mutableStateMapOf<String, Int>().apply {
                            columnasPerdidas.forEach { this[it] = 0 }
                        }
                    )
                )
            }
        }
    }
    var setsGanadosLocal by remember { mutableStateOf(0) }
    var setsGanadosVisitante by remember { mutableStateOf(0) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    Column(modifier = Modifier.padding(8.dp)) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(onClick = onVolver) {
                Text("🔙 Volver")
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("🏠 $equipoLocal vs $equipoVisitante", style = MaterialTheme.typography.titleMedium)
            }
        }

        Text("📋 Estadísticas del partido", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn {
            items(jugadores) { jugador ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        var nombreEditable by remember { mutableStateOf(TextFieldValue(jugador.nombre)) }

                        TextField(
                            value = nombreEditable,
                            onValueChange = {
                                nombreEditable = it
                                jugador.nombre = it.text
                            },
                            label = { Text("Nombre del jugador") }
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text("✅ Puntos Ganados")
                        columnasGanadas.filter { it.isNotBlank() }.forEach { tipo ->
                            if (!jugador.puntosGanados.containsKey(tipo)) {
                                jugador.puntosGanados[tipo] = 0
                            }
                            PuntoEditable(tipo, jugador.puntosGanados)
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text("❌ Puntos Perdidos")
                        columnasPerdidas.filter { it.isNotBlank() }.forEach { tipo ->
                            if (!jugador.puntosPerdidos.containsKey(tipo)) {
                                jugador.puntosPerdidos[tipo] = 0
                            }
                            PuntoEditable(tipo, jugador.puntosPerdidos)
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
                Text("📊 Totales del Partido", style = MaterialTheme.typography.titleMedium)

                val totalGanados = jugadores.sumOf { it.puntosGanados.values.sum() }
                val totalPerdidos = jugadores.sumOf { it.puntosPerdidos.values.sum() }

                Text("✅ Total puntos ganados (Equipo): $totalGanados")
                Text("❌ Total puntos perdidos (Rival): $totalPerdidos")
            }
            item {
                Spacer(modifier = Modifier.height(16.dp))

                Text("🧮 Sets", style = MaterialTheme.typography.titleMedium)
                Text("Equipo Local: $setsGanadosLocal sets ganados")
                Text("Equipo Visitante: $setsGanadosVisitante sets ganados")

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Button(onClick = {
                        var totalGanados = 0
                        var totalPerdidos = 0

                        jugadores.forEach { jugador ->
                            columnasGanadas.forEach { tipo ->
                                jugador.puntosGanados[tipo] = jugador.puntosGanados[tipo] ?: 0
                                totalGanados += jugador.puntosGanados[tipo]!!
                            }
                            columnasPerdidas.forEach { tipo ->
                                jugador.puntosPerdidos[tipo] = jugador.puntosPerdidos[tipo] ?: 0
                                totalPerdidos += jugador.puntosPerdidos[tipo]!!
                            }
                        }
                        println("Total ganados: $totalGanados / Total perdidos: $totalPerdidos")



                        if (totalGanados > totalPerdidos) {
                            setsGanadosLocal++
                        } else {
                            setsGanadosVisitante++
                        }

                        jugadores.forEach {
                            columnasGanadas.forEach { tipo -> it.puntosGanados[tipo] = 0 }
                            columnasPerdidas.forEach { tipo -> it.puntosPerdidos[tipo] = 0 }
                        }

                        Toast.makeText(context, "✅ Set finalizado", Toast.LENGTH_SHORT).show()

                    }) {
                        Text("🏁 Set finalizado")
                    }

                    Button(onClick = {
                        scope.launch {
                            val db = DatabaseProvider.getDatabase(context)

                            val resultadoFinalTexto = "$equipoVisitante ($setsGanadosVisitante) - $equipoLocal ($setsGanadosLocal) - ${
                                if (setsGanadosLocal > setsGanadosVisitante) "GANADO" else "PERDIDO"
                            }"

                            val partido = PartidoEntity(
                                equipoLocal = equipoLocal,
                                equipoVisitante = equipoVisitante,
                                fecha = System.currentTimeMillis(),
                                columnasGanadas = columnasGanadas.filter { it.isNotBlank() },
                                columnasPerdidas = columnasPerdidas.filter { it.isNotBlank() },
                                setsLocal = setsGanadosLocal,
                                setsVisitante = setsGanadosVisitante,
                                resultadoFinal = if (setsGanadosLocal > setsGanadosVisitante) "GANADO" else "PERDIDO"
                            )


                            val partidoId = db.partidoDao().insert(partido).toInt()

                            val jugadoresEntity = jugadores.map {
                                JugadorEntity(
                                    partidoId = partidoId,
                                    nombre = it.nombre,
                                    puntosGanados = it.puntosGanados,
                                    puntosPerdidos = it.puntosPerdidos
                                )
                            }

                            db.jugadorDao().insertAll(jugadoresEntity)

                            Toast.makeText(context, "🏆 Partido guardado: $resultadoFinalTexto", Toast.LENGTH_LONG).show()
                        }
                        onPartidoFinalizado()

                    }) {
                        Text("🎯 Partido finalizado")
                    }
                }
            }

        }
    }
}

    @Composable
    fun PuntoEditable(
        tipo: String,
        mapa: MutableMap<String, Int>
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(vertical = 4.dp)
        ) {
            Text("$tipo: ${mapa[tipo] ?: 0}", modifier = Modifier.width(150.dp))

            Button(onClick = {
                mapa[tipo] = (mapa[tipo] ?: 0) + 1
            }) {
                Text("+1")
            }

            Spacer(modifier = Modifier.width(4.dp))

            Button(onClick = {
                val actual = mapa[tipo] ?: 0
                if (actual > 0) {
                    mapa[tipo] = actual - 1
                }
            }) {
                Text("-1")
            }
        }
    }
