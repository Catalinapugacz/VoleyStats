package com.cata.voleystats.data

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [
        PartidoEntity::class,
        JugadorEntity::class,
        EquipoPersonalizadoEntity::class  // ⬅️ ¡AGREGADO AQUÍ!
    ],
    version = 2, // ⬅️ Asegurate de haber aumentado la versión si agregaste esta tabla
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun partidoDao(): PartidoDao
    abstract fun jugadorDao(): JugadorDao
    abstract fun equipoDao(): EquipoDao // ⬅️ ¡AGREGADO AQUÍ TAMBIÉN!
}
