package com.cata.voleystats

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll


@Composable
fun PantallaPersonalizacion(
    columnasGanadas: MutableList<String>,
    columnasPerdidas: MutableList<String>,
    equipoLocal: MutableState<String>,
    equipoVisitante: MutableState<String>,
    onFinalizar: () -> Unit
)
{
    val ganadasTemp = remember { List(5) { mutableStateOf(TextFieldValue(columnasGanadas.getOrNull(it) ?: "")) } }
    val perdidasTemp = remember { List(5) { mutableStateOf(TextFieldValue(columnasPerdidas.getOrNull(it) ?: "")) } }

    val scrollState = rememberScrollState()




    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {

        TextField(
            value = equipoLocal.value,
            onValueChange = { equipoLocal.value = it },
            label = { Text("Equipo local") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        )

        TextField(
            value = equipoVisitante.value,
            onValueChange = { equipoVisitante.value = it },
            label = { Text("Equipo visitante") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        )



        Text("🏐 Personalización de nombres de columnas", style = MaterialTheme.typography.headlineSmall)


        Spacer(modifier = Modifier.height(16.dp))

        Text("✅ Campos de puntos ganados", style = MaterialTheme.typography.titleMedium)
        ganadasTemp.forEachIndexed { i, campo ->
            TextField(
                value = campo.value,
                onValueChange = { campo.value = it },
                label = { Text("Ganado ${i + 1}") },
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("❌ Campos de puntos perdidos", style = MaterialTheme.typography.titleMedium)
        perdidasTemp.forEachIndexed { i, campo ->
            TextField(
                value = campo.value,
                onValueChange = { campo.value = it },
                label = { Text("Perdido ${i + 1}") },
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                columnasGanadas.clear()
                columnasGanadas.addAll(ganadasTemp.map { it.value.text }.filter { it.isNotBlank() })

                columnasPerdidas.clear()
                columnasPerdidas.addAll(perdidasTemp.map { it.value.text }.filter { it.isNotBlank() })

                onFinalizar()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Finalizar")
        }
    }
}
